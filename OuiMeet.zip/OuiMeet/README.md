# OuiMeet 📍

> **Une application mobile moderne pour trouver le point de rencontre parfait entre amis**

OuiMeet est une application React Native qui calcule automatiquement le point de rencontre optimal entre plusieurs adresses, en tenant compte des temps de trajet réels. Parfait pour organiser des week-ends entre amis, des cousinades ou toute autre rencontre !

---

## 📱 Fonctionnalités Complètes

### ✅ Implémenté

- ✨ **Calcul intelligent du point de rencontre**
  - Géocodage automatique des adresses avec Google Places API
  - Calcul du centre géographique optimal entre 2-10 adresses
  - Calcul des temps de trajet réels avec Google Distance Matrix API
  - Affichage du temps moyen et du temps maximum

- 🗺️ **Carte interactive**
  - Visualisation du point de rencontre avec marqueur étoile
  - Affichage de tous les points de départ
  - Lignes connectant les adresses au point central
  - Cercle de rayon autour du point de rencontre

- 🍽️ **Suggestions personnalisées**
  - Recherche de restaurants, cafés, bars, parcs à proximité
  - Filtrage basé sur les préférences alimentaires du groupe
  - Notation et distance depuis le point de rencontre
  - Photos et détails des lieux

- 👥 **Gestion des profils**
  - Authentification sécurisée (email/password)
  - Profils utilisateur avec nom d'affichage personnalisable
  - Sauvegarde de contacts avec préférences
  - Gestion des adresses favorites par contact

- 🎨 **Préférences détaillées**
  - Types de cuisine (Italian, Japanese, French, etc.)
  - Types d'activités (Cultural, Outdoor, Sports, etc.)
  - Niveaux de budget (Économique, Moyen, Élevé)
  - Options d'accessibilité

- 💾 **Persistance des données**
  - Sauvegarde automatique des événements dans Firebase
  - Historique des points de rencontre calculés
  - Synchronisation en temps réel

- 🔗 **Partage**
  - Partage du point de rencontre avec coordonnées
  - Export vers Google Maps
  - Partage des détails d'événement complets

---

## 🛠️ Stack Technique

### Frontend
- **React Native** `0.81.5` - Framework mobile cross-platform
- **Expo** `~54.0.24` - Plateforme de développement
- **TypeScript** `~5.9.2` - Type safety et meilleure DX
- **React** `19.1.0` - UI library

### Navigation
- **React Navigation** `7.x` - Navigation stack et tabs
- **@react-navigation/native-stack** - Native stack navigator
- **@react-navigation/bottom-tabs** - Tab navigation

### Backend & Services
- **Firebase Authentication** `12.6.0` - Authentification email/password
- **Cloud Firestore** `12.6.0` - Base de données NoSQL temps réel
- **Google Maps APIs**:
  - Places API (geocoding et autocomplete)
  - Distance Matrix API (calcul des trajets)
  - Maps SDK (affichage des cartes)

### UI & Maps
- **React Native Maps** `1.26.18` - Affichage de cartes natives
- **React Native Reanimated** `4.1.5` - Animations fluides
- **AsyncStorage** `1.24.0` - Stockage local

### Utilities
- **react-native-dotenv** `3.4.11` - Gestion des variables d'environnement
- **expo-location** `19.0.7` - Géolocalisation
- **expo-sharing** `14.0.7` - Partage natif

---

## 🚀 Installation et Configuration

### Prérequis

- Node.js `>= 18.x`
- npm ou yarn
- Expo CLI: `npm install -g expo-cli`
- Un compte Firebase
- Un compte Google Cloud Platform (pour Maps API)

### Installation

```bash
# Cloner le repository
git clone https://github.com/votre-username/ouimeet.git
cd ouimeet

# Installer les dépendances
npm install
```

### Configuration Firebase

1. **Créer un projet Firebase**
   - Allez sur [console.firebase.google.com](https://console.firebase.google.com)
   - Créez un nouveau projet
   - Donnez-lui un nom (ex: "OuiMeet")

2. **Activer les services**
   - **Authentication**: Activez "Email/Password"
   - **Firestore Database**: Créez une base en mode test
   - Créez ces collections:
     ```
     - events (documents d'événements)
     - people (contacts sauvegardés)
     - users (profils utilisateurs)
     ```

3. **Récupérer les clés de configuration**
   - Dans Project Settings > General
   - Copiez la configuration web

### Configuration Google Maps API

1. **Créer un projet Google Cloud**
   - Allez sur [console.cloud.google.com](https://console.cloud.google.com)
   - Créez un nouveau projet

2. **Activer les APIs nécessaires**
   - Maps SDK for Android
   - Maps SDK for iOS
   - Places API
   - Geocoding API
   - Distance Matrix API

3. **Créer une clé API**
   - Dans "APIs & Services" > "Credentials"
   - Créez une clé API
   - Restreignez-la aux APIs activées

### Variables d'environnement

Créez un fichier `.env` à la racine du projet:

```env
# Firebase Configuration
FIREBASE_API_KEY=AIzaSyAh5oFqFAQSEL2kUCPyupX6_4_VjkgoVM4
FIREBASE_AUTH_DOMAIN=ouimeet-12345.firebaseapp.com
FIREBASE_PROJECT_ID=ouimeet-12345
FIREBASE_STORAGE_BUCKET=ouimeet-12345.firebasestorage.app
FIREBASE_MESSAGING_SENDER_ID=371922090266
FIREBASE_APP_ID=1:371922090266:web:b6d7e737671f547466d4a3

# Google Maps API Key
MAPS_API_KEY=votre_google_maps_api_key
```

⚠️ **Important**: Ne commitez JAMAIS le fichier `.env` ! Il est déjà dans `.gitignore`.

### Lancement de l'application

```bash
# Lancer Expo
npm start

# Ou directement sur une plateforme
npm run ios      # iOS Simulator
npm run android  # Android Emulator
npm run web      # Navigateur web
```

### Scan du QR Code

1. Installez l'app **Expo Go** sur votre téléphone
2. Scannez le QR code affiché dans le terminal
3. L'app se chargera directement sur votre appareil

---

## 🎨 Design System

### Palette de couleurs
- **Primary Green**: `#00B884` - Énergique et moderne
- **Dark Green**: `#004D40` - Profondeur et élégance
- **Light Green**: `#A7F3D0` - Accents subtils
- **Muted Green**: `#6EE7B7` - Éléments secondaires

### Typographie
- **Tailles**: 12px (xs) à 48px (5xl)
- **Poids**: normal, medium (500), semibold (600), bold (700)
- **Hiérarchie**: Titres, sous-titres, corps, captions

### Composants UI
- **Button**: 4 variantes (primary, secondary, outline, ghost)
- **Card**: 3 variantes (elevated, outlined, flat)
- **Input**: États normal, focus, error avec helper text

---

## 📂 Architecture du Projet

```
OuiMeet/
├── src/
│   ├── components/
│   │   └── ui/                    # Composants UI réutilisables
│   │       ├── Button.tsx         # Boutons avec variantes
│   │       ├── Card.tsx           # Cartes Material Design
│   │       └── Input.tsx          # Champs de saisie
│   │
│   ├── screens/                   # Écrans de l'application
│   │   ├── AuthScreen.tsx         # Connexion/Inscription
│   │   ├── HomeScreen.tsx         # Accueil avec événements
│   │   ├── CreateEventScreen.tsx  # Création d'événement
│   │   ├── MapResultsScreen.tsx   # Affichage carte + résultats
│   │   ├── ProfileScreen.tsx      # Profil utilisateur
│   │   ├── PersonProfileScreen.tsx # Profil contact
│   │   └── EditPreferencesScreen.tsx # Édition préférences
│   │
│   ├── navigation/
│   │   ├── MainNavigator.tsx      # Navigation principale
│   │   └── types.ts               # Types de navigation
│   │
│   ├── services/                  # Services backend
│   │   ├── firebase.ts            # Init Firebase
│   │   ├── auth.ts                # Authentification
│   │   ├── firestore.ts           # CRUD Firestore
│   │   ├── geocoding.ts           # Géocodage Google Places
│   │   ├── meetingPoint.ts        # Calcul point de rencontre
│   │   ├── suggestions.ts         # Suggestions de lieux
│   │   └── sharing.ts             # Partage natif
│   │
│   ├── hooks/
│   │   └── useAuth.ts             # Hook d'authentification
│   │
│   ├── types/
│   │   ├── index.ts               # Types métier
│   │   └── env.d.ts               # Types variables d'env
│   │
│   └── constants/
│       ├── colors.ts              # Palette de couleurs
│       └── theme.ts               # Thème complet
│
├── App.tsx                        # Composant racine
├── index.ts                       # Point d'entrée
├── app.json                       # Config Expo
├── babel.config.js                # Config Babel
├── tsconfig.json                  # Config TypeScript
├── package.json                   # Dépendances
└── .env                           # Variables d'environnement
```

---

## 🔧 Scripts Disponibles

```bash
# Développement
npm start              # Lancer Expo
npm run ios            # Lancer sur iOS
npm run android        # Lancer sur Android
npm run web            # Lancer sur Web

# Build
npm run build          # Build production

# Utilitaires
npm run lint           # Linter le code
npm run type-check     # Vérifier les types
```

---

## 🐛 Troubleshooting

### Problème: L'app ne se lance pas
```bash
# Nettoyer le cache Expo
expo start -c

# Réinstaller les dépendances
rm -rf node_modules
npm install
```

### Problème: Erreur Firebase
- Vérifiez que les clés dans `.env` sont correctes
- Vérifiez que Firebase Authentication et Firestore sont activés

### Problème: Carte ne s'affiche pas
- Vérifiez que `MAPS_API_KEY` est configurée
- Vérifiez que les APIs Google Maps sont activées

---

## 📝 Prochaines Étapes (Roadmap)

### À court terme
- [ ] Autocomplete des adresses en temps réel
- [ ] Mode hors ligne avec cache
- [ ] Notifications push pour les événements
- [ ] Invitations par email/SMS

### À moyen terme
- [ ] Mode sombre
- [ ] Support de plusieurs langues (i18n)
- [ ] Historique des recherches
- [ ] Favoris et lieux enregistrés
- [ ] Intégration calendrier

### À long terme
- [ ] Version web responsive
- [ ] API publique
- [ ] Intégration Uber/transport
- [ ] Intelligence artificielle pour suggestions

---

## 🤝 Contribution

Les contributions sont les bienvenues ! Pour contribuer:

1. Forkez le projet
2. Créez une branche (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add AmazingFeature'`)
4. Pushez vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

---

## 📄 Licence

MIT License - voir le fichier [LICENSE](LICENSE) pour plus de détails

---

## 👨‍💻 Auteur

**Thibaut**

---

## 🙏 Remerciements

- Inspiré par Strava, Airbnb, et Nugget pour le design
- Firebase pour le backend
- Google Maps pour les services de cartographie
- La communauté React Native

---

<div align="center">
  <strong>Créé avec ❤️ pour faciliter les rencontres entre amis</strong>
</div>
