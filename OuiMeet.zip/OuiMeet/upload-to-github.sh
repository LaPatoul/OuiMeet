#!/bin/bash

echo "🚀 Script d'upload OuiMeet vers GitHub"
echo "======================================"
echo ""

# Vérifier si Git est installé
if ! command -v git &> /dev/null; then
    echo "❌ Git n'est pas installé. Installation..."
    sudo apt-get update
    sudo apt-get install -y git
fi

# Configuration Git
echo "📝 Configuration de Git..."
read -p "Votre nom: " git_name
read -p "Votre email: " git_email

git config --global user.name "$git_name"
git config --global user.email "$git_email"

# Initialiser le repo
echo "🔧 Initialisation du repository Git..."
git init

# Créer .gitignore si nécessaire
if [ ! -f .gitignore ]; then
    echo "📄 Création du .gitignore..."
    cat > .gitignore << 'EOF'
# Env
.env
.env.local

# Dependencies
node_modules/
.expo/
.expo-shared/

# Builds
android/
ios/
dist/
build/

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db

# Logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
EOF
fi

# Ajouter tous les fichiers
echo "📦 Ajout des fichiers..."
git add .

# Créer le commit
echo "💾 Création du commit..."
git commit -m "feat: Complete OuiMeet MVP implementation

- Firebase authentication
- Google Maps integration
- Event creation and management
- Profile management
- Preferences system
- Sharing functionality
- Complete UI component library
- Responsive design system"

# Demander l'URL du repo
echo ""
echo "🌐 Configuration du repository distant"
echo "---------------------------------------"
echo "Allez sur GitHub.com et créez un nouveau repository nommé 'OuiMeet'"
echo "Puis copiez l'URL du repository (ex: https://github.com/username/OuiMeet.git)"
echo ""
read -p "URL du repository GitHub: " repo_url

# Ajouter le remote
git remote add origin "$repo_url"

# Push
echo ""
echo "⬆️  Upload vers GitHub..."
git branch -M main
git push -u origin main

echo ""
echo "✅ Upload terminé!"
echo "🌐 Votre code est maintenant sur: $repo_url"
