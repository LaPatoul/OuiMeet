import { useState, useEffect } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { onAuthChange } from '../services/auth';

/**
 * Hook personnalisé pour gérer l'authentification
 * Usage:
 *   const { user, loading } = useAuth();
 */
export const useAuth = () => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('🔐 useAuth: Setting up auth listener...');

    try {
      const unsubscribe = onAuthChange((user) => {
        console.log('🔐 useAuth: Auth state changed:', user ? 'User logged in' : 'No user');
        setUser(user);
        setLoading(false);
      });

      // Set a timeout to stop loading even if Firebase doesn't respond
      const timeout = setTimeout(() => {
        console.log('⚠️  useAuth: Timeout - Firebase not responding, stopping loading');
        setLoading(false);
      }, 3000);

      // Cleanup subscription on unmount
      return () => {
        clearTimeout(timeout);
        unsubscribe();
      };
    } catch (error) {
      console.error('❌ useAuth: Error setting up auth listener:', error);
      setLoading(false);
    }
  }, []);

  return { user, loading };
};
