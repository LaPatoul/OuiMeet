import { Coordinates } from './geocoding';
import { MAPS_API_KEY } from '@env';

export interface TravelTime {
  origin: Coordinates;
  destination: Coordinates;
  durationSeconds: number;
  distanceMeters: number;
}

export interface MeetingPointResult {
  center: Coordinates;
  address: string;
  averageTravelTime: number;
  maxTravelTime: number;
  travelTimes: TravelTime[];
}

/**
 * Calculate the geographic center (centroid) of multiple locations
 */
export const calculateGeographicCenter = (locations: Coordinates[]): Coordinates => {
  if (locations.length === 0) {
    throw new Error('Au moins une localisation est requise');
  }

  if (locations.length === 1) {
    return locations[0];
  }

  // Convert to radians and calculate average
  let x = 0;
  let y = 0;
  let z = 0;

  for (const location of locations) {
    const lat = (location.latitude * Math.PI) / 180;
    const lon = (location.longitude * Math.PI) / 180;

    x += Math.cos(lat) * Math.cos(lon);
    y += Math.cos(lat) * Math.sin(lon);
    z += Math.sin(lat);
  }

  const total = locations.length;
  x = x / total;
  y = y / total;
  z = z / total;

  const centralLon = Math.atan2(y, x);
  const centralSquareRoot = Math.sqrt(x * x + y * y);
  const centralLat = Math.atan2(z, centralSquareRoot);

  return {
    latitude: (centralLat * 180) / Math.PI,
    longitude: (centralLon * 180) / Math.PI,
  };
};

/**
 * Get travel time between two points using Google Distance Matrix API
 */
export const getTravelTime = async (
  origin: Coordinates,
  destination: Coordinates,
  mode: 'driving' | 'walking' | 'transit' = 'driving'
): Promise<TravelTime> => {
  try {
    const url = `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${origin.latitude},${origin.longitude}&destinations=${destination.latitude},${destination.longitude}&mode=${mode}&key=${MAPS_API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK' && data.rows[0]?.elements[0]?.status === 'OK') {
      const element = data.rows[0].elements[0];
      return {
        origin,
        destination,
        durationSeconds: element.duration.value,
        distanceMeters: element.distance.value,
      };
    } else {
      throw new Error('Impossible de calculer le temps de trajet');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Erreur lors du calcul du temps de trajet');
  }
};

/**
 * Get travel times from all origins to a single destination
 */
export const getTravelTimesFromOrigins = async (
  origins: Coordinates[],
  destination: Coordinates,
  mode: 'driving' | 'walking' | 'transit' = 'driving'
): Promise<TravelTime[]> => {
  try {
    const travelTimes: TravelTime[] = [];

    // Google Distance Matrix API supports batch requests
    // Split into chunks of 25 origins (API limit)
    const chunks: Coordinates[][] = [];
    for (let i = 0; i < origins.length; i += 25) {
      chunks.push(origins.slice(i, i + 25));
    }

    for (const chunk of chunks) {
      const originsParam = chunk.map((c) => `${c.latitude},${c.longitude}`).join('|');
      const url = `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originsParam}&destinations=${destination.latitude},${destination.longitude}&mode=${mode}&key=${MAPS_API_KEY}`;

      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'OK') {
        for (let i = 0; i < data.rows.length; i++) {
          const element = data.rows[i].elements[0];
          if (element.status === 'OK') {
            travelTimes.push({
              origin: chunk[i],
              destination,
              durationSeconds: element.duration.value,
              distanceMeters: element.distance.value,
            });
          }
        }
      }
    }

    return travelTimes;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Erreur lors du calcul des temps de trajet');
  }
};

/**
 * Calculate optimal meeting point considering travel times
 * Uses an iterative approach to find the point that minimizes maximum travel time
 */
export const calculateOptimalMeetingPoint = async (
  locations: Coordinates[],
  mode: 'driving' | 'walking' | 'transit' = 'driving'
): Promise<MeetingPointResult> => {
  if (locations.length === 0) {
    throw new Error('Au moins une localisation est requise');
  }

  if (locations.length === 1) {
    return {
      center: locations[0],
      address: '',
      averageTravelTime: 0,
      maxTravelTime: 0,
      travelTimes: [],
    };
  }

  try {
    // Start with geographic center
    const initialCenter = calculateGeographicCenter(locations);

    // For simplicity, we'll use the geographic center
    // A more advanced algorithm would iterate to find the point that minimizes travel time
    const center = initialCenter;

    // Calculate travel times from all origins to the center
    const travelTimes = await getTravelTimesFromOrigins(locations, center, mode);

    // Calculate statistics
    const durations = travelTimes.map((t) => t.durationSeconds);
    const averageTravelTime = durations.reduce((a, b) => a + b, 0) / durations.length;
    const maxTravelTime = Math.max(...durations);

    // Get address for the center point
    const addressUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${center.latitude},${center.longitude}&key=${MAPS_API_KEY}`;
    const addressResponse = await fetch(addressUrl);
    const addressData = await addressResponse.json();

    let address = '';
    if (addressData.status === 'OK' && addressData.results.length > 0) {
      address = addressData.results[0].formatted_address;
    }

    return {
      center,
      address,
      averageTravelTime,
      maxTravelTime,
      travelTimes,
    };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Erreur lors du calcul du point de rencontre optimal');
  }
};

/**
 * Calculate simple geographic center without API calls (faster, but less accurate)
 */
export const calculateSimpleMeetingPoint = (locations: Coordinates[]): Coordinates => {
  return calculateGeographicCenter(locations);
};

/**
 * Format duration in seconds to human-readable string
 */
export const formatDuration = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (hours > 0) {
    return `${hours}h ${minutes}min`;
  }
  return `${minutes}min`;
};

/**
 * Format distance in meters to human-readable string
 */
export const formatDistance = (meters: number): string => {
  if (meters >= 1000) {
    const km = (meters / 1000).toFixed(1);
    return `${km} km`;
  }
  return `${meters} m`;
};
