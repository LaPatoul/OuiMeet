import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import { auth } from './firebase';

/**
 * Authentication Service
 * Facilite l'utilisation de Firebase Auth
 */

// S'inscrire avec email et mot de passe
export const signUp = async (email: string, password: string) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return { user: userCredential.user, error: null };
  } catch (error: any) {
    console.error('Sign up error:', error);
    return { user: null, error: error.message };
  }
};

// Se connecter avec email et mot de passe
export const signIn = async (email: string, password: string) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { user: userCredential.user, error: null };
  } catch (error: any) {
    console.error('Sign in error:', error);
    return { user: null, error: error.message };
  }
};

// Se déconnecter
export const signOut = async () => {
  try {
    await firebaseSignOut(auth);
    return { error: null };
  } catch (error: any) {
    console.error('Sign out error:', error);
    return { error: error.message };
  }
};

// Écouter les changements d'authentification
export const onAuthChange = (callback: (user: FirebaseUser | null) => void) => {
  try {
    if (!auth) {
      console.warn('⚠️  Auth not initialized, calling callback with null user');
      callback(null);
      return () => {}; // Return empty unsubscribe function
    }
    return onAuthStateChanged(auth, callback);
  } catch (error) {
    console.error('❌ Error in onAuthChange:', error);
    callback(null);
    return () => {};
  }
};

// Obtenir l'utilisateur actuel
export const getCurrentUser = () => {
  return auth.currentUser;
};

// Mettre à jour le profil utilisateur
export const updateUserProfile = async (displayName?: string, photoURL?: string) => {
  try {
    const user = auth.currentUser;
    if (!user) {
      return { error: 'Aucun utilisateur connecté' };
    }

    await updateProfile(user, {
      displayName: displayName || user.displayName,
      photoURL: photoURL || user.photoURL,
    });

    return { error: null };
  } catch (error: any) {
    console.error('Update profile error:', error);
    return { error: error.message };
  }
};
