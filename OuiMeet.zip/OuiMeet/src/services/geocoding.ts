import { MAPS_API_KEY } from '@env';

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface GeocodingResult {
  address: string;
  coordinates: Coordinates;
  placeId?: string;
}

export interface AddressSuggestion {
  description: string;
  placeId: string;
}

/**
 * Geocode an address to coordinates using Google Maps Geocoding API
 */
export const geocodeAddress = async (address: string): Promise<GeocodingResult> => {
  try {
    const encodedAddress = encodeURIComponent(address);
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodedAddress}&key=${MAPS_API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK' && data.results.length > 0) {
      const result = data.results[0];
      return {
        address: result.formatted_address,
        coordinates: {
          latitude: result.geometry.location.lat,
          longitude: result.geometry.location.lng,
        },
        placeId: result.place_id,
      };
    } else if (data.status === 'ZERO_RESULTS') {
      throw new Error('Aucune adresse trouvée pour cette recherche');
    } else if (data.status === 'REQUEST_DENIED') {
      throw new Error('Clé API invalide ou domaine non autorisé');
    } else {
      throw new Error(`Erreur de géocodage: ${data.status}`);
    }
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Erreur lors du géocodage de l\'adresse');
  }
};

/**
 * Get address suggestions using Google Places Autocomplete API
 */
export const getAddressSuggestions = async (input: string): Promise<AddressSuggestion[]> => {
  try {
    if (input.length < 3) {
      return [];
    }

    const encodedInput = encodeURIComponent(input);
    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodedInput}&key=${MAPS_API_KEY}&language=fr`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK' && data.predictions) {
      return data.predictions.map((prediction: any) => ({
        description: prediction.description,
        placeId: prediction.place_id,
      }));
    }

    return [];
  } catch (error) {
    console.error('Error fetching address suggestions:', error);
    return [];
  }
};

/**
 * Get coordinates for a place using its Place ID
 */
export const getPlaceDetails = async (placeId: string): Promise<GeocodingResult> => {
  try {
    const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=formatted_address,geometry&key=${MAPS_API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK' && data.result) {
      const result = data.result;
      return {
        address: result.formatted_address,
        coordinates: {
          latitude: result.geometry.location.lat,
          longitude: result.geometry.location.lng,
        },
        placeId,
      };
    } else {
      throw new Error('Impossible de récupérer les détails du lieu');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Erreur lors de la récupération des détails du lieu');
  }
};

/**
 * Reverse geocode coordinates to an address
 */
export const reverseGeocode = async (coordinates: Coordinates): Promise<string> => {
  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${coordinates.latitude},${coordinates.longitude}&key=${MAPS_API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK' && data.results.length > 0) {
      return data.results[0].formatted_address;
    } else {
      throw new Error('Aucune adresse trouvée pour ces coordonnées');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Erreur lors du géocodage inverse');
  }
};
