import { MAPS_API_KEY } from '@env';
import { Coordinates } from './geocoding';
import { Suggestion, Preferences } from '../types';

export interface PlaceSearchParams {
  location: Coordinates;
  radius?: number; // in meters, default 1000
  type?: string; // restaurant, cafe, bar, etc.
  keyword?: string;
  minRating?: number;
}

/**
 * Search for places near a location using Google Places API
 */
export const searchNearbyPlaces = async (
  params: PlaceSearchParams
): Promise<Suggestion[]> => {
  try {
    const {
      location,
      radius = 1000,
      type = 'restaurant',
      keyword,
      minRating = 3.5,
    } = params;

    const url = new URL('https://maps.googleapis.com/maps/api/place/nearbysearch/json');
    url.searchParams.append('location', `${location.latitude},${location.longitude}`);
    url.searchParams.append('radius', radius.toString());
    url.searchParams.append('type', type);
    if (keyword) {
      url.searchParams.append('keyword', keyword);
    }
    url.searchParams.append('key', MAPS_API_KEY);

    const response = await fetch(url.toString());
    const data = await response.json();

    if (data.status === 'OK' && data.results) {
      const suggestions: Suggestion[] = data.results
        .filter((place: any) => {
          // Filter by minimum rating
          return !place.rating || place.rating >= minRating;
        })
        .map((place: any) => {
          // Calculate distance from meeting point
          const distance = calculateDistance(
            location,
            {
              latitude: place.geometry.location.lat,
              longitude: place.geometry.location.lng,
            }
          );

          return {
            id: place.place_id,
            name: place.name,
            type: mapPlaceType(place.types),
            address: place.vicinity,
            latitude: place.geometry.location.lat,
            longitude: place.geometry.location.lng,
            rating: place.rating,
            priceLevel: place.price_level,
            distance,
            imageUrl: place.photos?.[0]
              ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photo_reference=${place.photos[0].photo_reference}&key=${MAPS_API_KEY}`
              : undefined,
          };
        })
        .slice(0, 10); // Limit to 10 suggestions

      return suggestions;
    }

    return [];
  } catch (error) {
    console.error('Error searching nearby places:', error);
    return [];
  }
};

/**
 * Get personalized suggestions based on group preferences
 */
export const getPersonalizedSuggestions = async (
  location: Coordinates,
  preferences: Preferences[],
  radius: number = 1000
): Promise<Suggestion[]> => {
  try {
    // Aggregate preferences from all participants
    const aggregatedPreferences = aggregatePreferences(preferences);

    // Search for different types of places
    const searches: Promise<Suggestion[]>[] = [];

    // Search for restaurants based on food preferences
    if (aggregatedPreferences.foodTypes.length > 0) {
      for (const foodType of aggregatedPreferences.foodTypes.slice(0, 3)) {
        searches.push(
          searchNearbyPlaces({
            location,
            radius,
            type: 'restaurant',
            keyword: foodType.toLowerCase(),
          })
        );
      }
    } else {
      // Default restaurant search
      searches.push(
        searchNearbyPlaces({
          location,
          radius,
          type: 'restaurant',
        })
      );
    }

    // Search for cafes
    searches.push(
      searchNearbyPlaces({
        location,
        radius,
        type: 'cafe',
      })
    );

    // Search for bars if budget allows
    if (aggregatedPreferences.budget !== 'low') {
      searches.push(
        searchNearbyPlaces({
          location,
          radius,
          type: 'bar',
        })
      );
    }

    // Search for activities based on preferences
    if (aggregatedPreferences.activityTypes.includes('Outdoor')) {
      searches.push(
        searchNearbyPlaces({
          location,
          radius: radius * 2, // Larger radius for parks
          type: 'park',
        })
      );
    }

    if (aggregatedPreferences.activityTypes.includes('Cultural')) {
      searches.push(
        searchNearbyPlaces({
          location,
          radius,
          type: 'museum',
        })
      );
    }

    // Execute all searches in parallel
    const results = await Promise.all(searches);

    // Flatten and deduplicate results
    const allSuggestions = results.flat();
    const uniqueSuggestions = deduplicateSuggestions(allSuggestions);

    // Score and sort suggestions
    const scoredSuggestions = uniqueSuggestions.map((suggestion) => ({
      ...suggestion,
      matchScore: calculateMatchScore(suggestion, aggregatedPreferences),
    }));

    // Sort by match score and rating
    scoredSuggestions.sort((a, b) => {
      const scoreA = (a.matchScore || 0) + (a.rating || 0) * 10;
      const scoreB = (b.matchScore || 0) + (b.rating || 0) * 10;
      return scoreB - scoreA;
    });

    return scoredSuggestions.slice(0, 15); // Return top 15
  } catch (error) {
    console.error('Error getting personalized suggestions:', error);
    return [];
  }
};

/**
 * Aggregate preferences from multiple people
 */
const aggregatePreferences = (preferences: Preferences[]): Preferences => {
  const aggregated: Preferences = {
    foodTypes: [],
    activityTypes: [],
    budget: 'medium',
    accessibility: false,
  };

  // Collect all food types
  const foodTypesMap = new Map<string, number>();
  preferences.forEach((pref) => {
    pref.foodTypes?.forEach((food) => {
      foodTypesMap.set(food, (foodTypesMap.get(food) || 0) + 1);
    });
  });

  // Sort by frequency and take top choices
  aggregated.foodTypes = Array.from(foodTypesMap.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([food]) => food);

  // Collect all activity types
  const activityTypesMap = new Map<string, number>();
  preferences.forEach((pref) => {
    pref.activityTypes?.forEach((activity) => {
      activityTypesMap.set(activity, (activityTypesMap.get(activity) || 0) + 1);
    });
  });

  aggregated.activityTypes = Array.from(activityTypesMap.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([activity]) => activity);

  // Use the most common budget level
  const budgets = preferences.map((p) => p.budget).filter(Boolean) as string[];
  if (budgets.length > 0) {
    const budgetCounts = budgets.reduce((acc, budget) => {
      acc[budget] = (acc[budget] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    aggregated.budget = Object.entries(budgetCounts).sort((a, b) => b[1] - a[1])[0][0] as 'low' | 'medium' | 'high';
  }

  // Accessibility is true if any participant needs it
  aggregated.accessibility = preferences.some((p) => p.accessibility);

  return aggregated;
};

/**
 * Calculate match score for a suggestion based on preferences
 */
const calculateMatchScore = (
  suggestion: Suggestion,
  preferences: Preferences
): number => {
  let score = 50; // Base score

  // Food type match
  if (preferences.foodTypes && preferences.foodTypes.length > 0) {
    const matchesFoodType = preferences.foodTypes.some((foodType) =>
      suggestion.name.toLowerCase().includes(foodType.toLowerCase())
    );
    if (matchesFoodType) {
      score += 30;
    }
  }

  // Budget match
  if (suggestion.priceLevel !== undefined && preferences.budget) {
    const budgetMapping = { low: 1, medium: 2, high: 3 };
    const targetPrice = budgetMapping[preferences.budget];
    const priceDiff = Math.abs(suggestion.priceLevel - targetPrice);
    score += (3 - priceDiff) * 5; // Closer to target = higher score
  }

  // Rating bonus
  if (suggestion.rating) {
    score += suggestion.rating * 2;
  }

  // Distance penalty (closer is better)
  if (suggestion.distance) {
    if (suggestion.distance < 200) {
      score += 10;
    } else if (suggestion.distance < 500) {
      score += 5;
    }
  }

  return Math.min(100, Math.max(0, score));
};

/**
 * Map Google Place types to our suggestion types
 */
const mapPlaceType = (types: string[]): Suggestion['type'] => {
  if (types.includes('restaurant')) return 'restaurant';
  if (types.includes('cafe')) return 'cafe';
  if (types.includes('bar') || types.includes('night_club')) return 'bar';
  if (types.includes('park')) return 'park';
  return 'other';
};

/**
 * Calculate distance between two coordinates (Haversine formula)
 */
const calculateDistance = (coord1: Coordinates, coord2: Coordinates): number => {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = (coord1.latitude * Math.PI) / 180;
  const φ2 = (coord2.latitude * Math.PI) / 180;
  const Δφ = ((coord2.latitude - coord1.latitude) * Math.PI) / 180;
  const Δλ = ((coord2.longitude - coord1.longitude) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // Distance in meters
};

/**
 * Remove duplicate suggestions based on place ID
 */
const deduplicateSuggestions = (suggestions: Suggestion[]): Suggestion[] => {
  const seen = new Set<string>();
  return suggestions.filter((suggestion) => {
    if (seen.has(suggestion.id)) {
      return false;
    }
    seen.add(suggestion.id);
    return true;
  });
};
