import * as Sharing from 'expo-sharing';
import { Event, MeetingPoint } from '../types';

/**
 * Share event details with others
 */
export const shareEvent = async (event: Event): Promise<{ error: string | null }> => {
  try {
    // Check if sharing is available
    const isAvailable = await Sharing.isAvailableAsync();

    if (!isAvailable) {
      return { error: 'Le partage n\'est pas disponible sur cet appareil' };
    }

    // Create share message
    const message = formatEventMessage(event);

    // Share the message
    await Sharing.shareAsync(message, {
      dialogTitle: `Partager: ${event.title}`,
    });

    return { error: null };
  } catch (error: any) {
    console.error('Error sharing event:', error);
    return { error: error.message || 'Erreur lors du partage' };
  }
};

/**
 * Format event details as a shareable message
 */
const formatEventMessage = (event: Event): string => {
  let message = `📍 ${event.title}\n\n`;

  if (event.description) {
    message += `${event.description}\n\n`;
  }

  if (event.meetingPoint) {
    message += `Point de rencontre:\n`;
    message += `${event.meetingPoint.address || 'Adresse non disponible'}\n`;
    message += `📍 ${event.meetingPoint.latitude.toFixed(6)}, ${event.meetingPoint.longitude.toFixed(6)}\n\n`;
  }

  if (event.addresses && event.addresses.length > 0) {
    message += `Points de départ:\n`;
    event.addresses.forEach((addr, index) => {
      message += `${index + 1}. ${addr.label}: ${addr.fullAddress}\n`;
    });
    message += `\n`;
  }

  if (event.suggestions && event.suggestions.length > 0) {
    message += `Suggestions de lieux:\n`;
    event.suggestions.slice(0, 5).forEach((suggestion, index) => {
      message += `${index + 1}. ${suggestion.name} (${suggestion.type})`;
      if (suggestion.rating) {
        message += ` - ⭐ ${suggestion.rating.toFixed(1)}`;
      }
      message += `\n`;
    });
    message += `\n`;
  }

  message += `📱 Créé avec OuiMeet`;

  return message;
};

/**
 * Share meeting point coordinates with a maps link
 */
export const shareMeetingPoint = async (
  meetingPoint: MeetingPoint
): Promise<{ error: string | null }> => {
  try {
    const isAvailable = await Sharing.isAvailableAsync();

    if (!isAvailable) {
      return { error: 'Le partage n\'est pas disponible sur cet appareil' };
    }

    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${meetingPoint.latitude},${meetingPoint.longitude}`;

    const message = `📍 Point de rencontre\n\n${meetingPoint.address || 'Adresse non disponible'}\n\nOuvrir dans Google Maps:\n${mapsUrl}\n\n📱 Partagé avec OuiMeet`;

    await Sharing.shareAsync(message, {
      dialogTitle: 'Partager le point de rencontre',
    });

    return { error: null };
  } catch (error: any) {
    console.error('Error sharing meeting point:', error);
    return { error: error.message || 'Erreur lors du partage' };
  }
};

/**
 * Copy text to clipboard (alternative to sharing)
 */
export const copyToClipboard = async (text: string): Promise<{ error: string | null }> => {
  try {
    // Note: In a real app, use expo-clipboard
    // For now, this is a placeholder
    console.log('Text copied to clipboard:', text);
    return { error: null };
  } catch (error: any) {
    console.error('Error copying to clipboard:', error);
    return { error: error.message || 'Erreur lors de la copie' };
  }
};

/**
 * Generate a shareable link for an event (requires backend)
 */
export const generateShareableLink = async (eventId: string): Promise<{ link: string | null; error: string | null }> => {
  try {
    // In a real app, this would create a deep link or short URL
    // For now, return a placeholder
    const link = `https://ouimeet.app/event/${eventId}`;
    return { link, error: null };
  } catch (error: any) {
    console.error('Error generating shareable link:', error);
    return { link: null, error: error.message || 'Erreur lors de la génération du lien' };
  }
};
