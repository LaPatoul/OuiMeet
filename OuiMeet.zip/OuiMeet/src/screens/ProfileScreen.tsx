import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { theme } from '../constants/theme';
import { Card } from '../components/ui';
import { useAuth } from '../hooks/useAuth';
import { signOut, updateUserProfile } from '../services/auth';
import { getPeople } from '../services/firestore';
import { Person } from '../types';
import { Button, Input } from '../components/ui';

export const ProfileScreen = ({ navigation }: any) => {
  const { user } = useAuth();
  const [savedPeople, setSavedPeople] = useState<Person[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingProfile, setEditingProfile] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    const fetchPeople = async () => {
      if (!user) {
        setLoading(false);
        return;
      }

      setLoading(true);
      setDisplayName(user.displayName || '');

      const { data, error } = await getPeople(user.uid);

      if (error) {
        console.error('Error fetching people:', error);
      } else {
        setSavedPeople(data);
      }

      setLoading(false);
    };

    fetchPeople();
  }, [user]);

  const handleSaveProfile = async () => {
    setSavingProfile(true);

    const { error } = await updateUserProfile(displayName);

    if (error) {
      Alert.alert('Erreur', error);
    } else {
      setEditingProfile(false);
      Alert.alert('Succès', 'Profil mis à jour avec succès');
    }

    setSavingProfile(false);
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Déconnexion',
      'Êtes-vous sûr de vouloir vous déconnecter ?',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Déconnexion',
          style: 'destructive',
          onPress: async () => {
            const { error } = await signOut();
            if (error) {
              Alert.alert('Erreur', error);
            }
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Profil</Text>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* User Info */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {(displayName || user?.email)?.charAt(0).toUpperCase() || 'U'}
            </Text>
          </View>

          {editingProfile ? (
            <>
              <Input
                label="Nom d'affichage"
                value={displayName}
                onChangeText={setDisplayName}
                placeholder="Votre nom"
                containerStyle={styles.profileInput}
              />
              <View style={styles.profileActions}>
                <Button
                  title="Annuler"
                  variant="outline"
                  onPress={() => {
                    setDisplayName(user?.displayName || '');
                    setEditingProfile(false);
                  }}
                  style={styles.profileButton}
                />
                <Button
                  title={savingProfile ? 'Enregistrement...' : 'Enregistrer'}
                  onPress={handleSaveProfile}
                  disabled={savingProfile}
                  style={styles.profileButton}
                />
              </View>
            </>
          ) : (
            <>
              <Text style={styles.userName}>
                {displayName || user?.displayName || 'Utilisateur'}
              </Text>
              <Text style={styles.userEmail}>{user?.email || ''}</Text>
              <TouchableOpacity
                onPress={() => setEditingProfile(true)}
                style={styles.editProfileButton}
              >
                <Text style={styles.editProfileText}>Modifier le profil</Text>
              </TouchableOpacity>
            </>
          )}
        </Card>

        {/* Saved People */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Mes contacts</Text>
          <Text style={styles.sectionSubtitle}>
            Enregistrez les profils de vos amis pour des suggestions personnalisées
          </Text>

          {loading ? (
            <Card variant="flat" padding="lg">
              <ActivityIndicator size="large" color={theme.colors.primary.main} />
            </Card>
          ) : savedPeople.length === 0 ? (
            <Card variant="flat" padding="lg">
              <Text style={styles.emptyText}>Aucun contact enregistré</Text>
              <Text style={styles.emptySubtext}>
                Ajoutez des contacts pour faciliter l'organisation de vos événements
              </Text>
            </Card>
          ) : (
            savedPeople.map((person: Person) => (
              <Card
                key={person.id}
                variant="outlined"
                padding="md"
                style={styles.personCard}
                onPress={() =>
                  navigation.navigate('PersonProfile', { personId: person.id })
                }
              >
                <View style={styles.personAvatar}>
                  <Text style={styles.personAvatarText}>
                    {person.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <View style={styles.personInfo}>
                  <Text style={styles.personName}>{person.name}</Text>
                  <Text style={styles.personDetails}>
                    {person.savedAddresses?.length || 0} adresses enregistrées
                  </Text>
                </View>
              </Card>
            ))
          )}
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Paramètres</Text>

          <Card variant="outlined" padding="none">
            <TouchableOpacity style={styles.settingItem}>
              <Text style={styles.settingText}>Notifications</Text>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>

            <View style={styles.settingDivider} />

            <TouchableOpacity style={styles.settingItem}>
              <Text style={styles.settingText}>Préférences</Text>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>

            <View style={styles.settingDivider} />

            <TouchableOpacity style={styles.settingItem}>
              <Text style={styles.settingText}>Confidentialité</Text>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>

            <View style={styles.settingDivider} />

            <TouchableOpacity style={styles.settingItem} onPress={handleSignOut}>
              <Text style={[styles.settingText, styles.logoutText]}>
                Déconnexion
              </Text>
            </TouchableOpacity>
          </Card>
        </View>

        {/* App Info */}
        <Text style={styles.appVersion}>OuiMeet v1.0.0</Text>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background.primary,
  },

  header: {
    paddingTop: theme.spacing['3xl'],
    paddingHorizontal: theme.spacing.lg,
    paddingBottom: theme.spacing.lg,
    backgroundColor: theme.colors.background.primary,
  },

  title: {
    fontSize: theme.typography.fontSize['3xl'],
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.text.primary,
  },

  content: {
    flex: 1,
  },

  scrollContent: {
    padding: theme.spacing.lg,
    paddingBottom: theme.spacing['2xl'],
  },

  section: {
    marginBottom: theme.spacing.xl,
  },

  avatar: {
    width: 80,
    height: 80,
    borderRadius: theme.borderRadius.full,
    backgroundColor: theme.colors.primary.main,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: theme.spacing.md,
  },

  avatarText: {
    fontSize: theme.typography.fontSize['3xl'],
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.text.inverse,
  },

  userName: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.text.primary,
    textAlign: 'center',
    marginBottom: theme.spacing.xs,
  },

  userEmail: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.text.secondary,
    textAlign: 'center',
  },

  profileInput: {
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },

  profileActions: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
    justifyContent: 'center',
  },

  profileButton: {
    flex: 1,
  },

  editProfileButton: {
    marginTop: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    paddingHorizontal: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    backgroundColor: theme.colors.primary.light,
    alignSelf: 'center',
  },

  editProfileText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.primary.dark,
    fontWeight: theme.typography.fontWeight.medium,
  },

  sectionTitle: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.text.primary,
    marginBottom: theme.spacing.xs,
  },

  sectionSubtitle: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.secondary,
    marginBottom: theme.spacing.md,
  },

  emptyText: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.text.secondary,
    textAlign: 'center',
    marginBottom: theme.spacing.xs,
  },

  emptySubtext: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.tertiary,
    textAlign: 'center',
  },

  personCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },

  personAvatar: {
    width: 48,
    height: 48,
    borderRadius: theme.borderRadius.full,
    backgroundColor: theme.colors.primary.light,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: theme.spacing.md,
  },

  personAvatarText: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.primary.dark,
  },

  personInfo: {
    flex: 1,
  },

  personName: {
    fontSize: theme.typography.fontSize.base,
    fontWeight: theme.typography.fontWeight.medium,
    color: theme.colors.text.primary,
    marginBottom: theme.spacing.xs,
  },

  personDetails: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.secondary,
  },

  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.md,
  },

  settingDivider: {
    height: 1,
    backgroundColor: theme.colors.border.light,
    marginHorizontal: theme.spacing.md,
  },

  settingText: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.text.primary,
  },

  settingArrow: {
    fontSize: theme.typography.fontSize.xl,
    color: theme.colors.text.tertiary,
  },

  logoutText: {
    color: theme.colors.error,
  },

  appVersion: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.tertiary,
    textAlign: 'center',
    marginTop: theme.spacing.lg,
  },
});
