import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
// import MapView, { Marker, Circle, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/types';
import { Card, Button } from '../components/ui';
import { MeetingPointResult, formatDuration, formatDistance } from '../services/meetingPoint';
import { Suggestion } from '../types';
import { shareMeetingPoint } from '../services/sharing';
import { styles } from './MapResultsScreen.styles';

type Props = NativeStackScreenProps<RootStackParamList, 'MapResults'>;

export const MapResultsScreen: React.FC<Props> = ({ route, navigation }) => {
  const { meetingPoint, addresses, suggestions = [] } = route.params;
  const [selectedSuggestion, setSelectedSuggestion] = useState<Suggestion | null>(null);
  const [mapReady, setMapReady] = useState(false);

  // Calculate map region to show all markers
  const getInitialRegion = () => {
    const allCoordinates = [
      { latitude: meetingPoint.center.latitude, longitude: meetingPoint.center.longitude },
      ...addresses.map((addr) => ({ latitude: addr.latitude, longitude: addr.longitude })),
    ];

    const lats = allCoordinates.map((c) => c.latitude);
    const lngs = allCoordinates.map((c) => c.longitude);

    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);

    const centerLat = (minLat + maxLat) / 2;
    const centerLng = (minLng + maxLng) / 2;
    const latDelta = (maxLat - minLat) * 1.5; // Add padding
    const lngDelta = (maxLng - minLng) * 1.5;

    return {
      latitude: centerLat,
      longitude: centerLng,
      latitudeDelta: Math.max(latDelta, 0.05), // Minimum zoom level
      longitudeDelta: Math.max(lngDelta, 0.05),
    };
  };

  const handleSuggestionPress = (suggestion: Suggestion) => {
    setSelectedSuggestion(suggestion);
  };

  const handleNavigateToSuggestion = (suggestion: Suggestion) => {
    // Open in external maps app
    const url = `https://www.google.com/maps/search/?api=1&query=${suggestion.latitude},${suggestion.longitude}`;
    Alert.alert(
      'Navigation',
      `Ouvrir ${suggestion.name} dans Google Maps ?`,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Ouvrir',
          onPress: () => {
            // In a real app, use Linking.openURL(url)
            console.log('Opening:', url);
          },
        },
      ]
    );
  };

  const handleShare = async () => {
    const meetingPointToShare = {
      latitude: meetingPoint.center.latitude,
      longitude: meetingPoint.center.longitude,
      address: meetingPoint.address,
      type: 'calculated' as const,
    };

    const { error } = await shareMeetingPoint(meetingPointToShare);

    if (error) {
      Alert.alert('Erreur', error);
    }
  };

  return (
    <View style={styles.container}>
      {/* Header with Share Button */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Point de rencontre</Text>
        <TouchableOpacity onPress={handleShare} style={styles.shareButton}>
          <Text style={styles.shareButtonText}>↗️</Text>
        </TouchableOpacity>
      </View>

      {/* Map View - Temporarily disabled for Expo Go */}
      <View style={styles.map}>
        <View style={styles.mapPlaceholder}>
          <Text style={styles.mapPlaceholderTitle}>📍 Carte Interactive</Text>
          <Text style={styles.mapPlaceholderText}>
            La carte sera disponible dans la version finale.{'\n'}
            Scroll en bas pour voir les détails du point de rencontre.
          </Text>
          <View style={styles.coordinatesBox}>
            <Text style={styles.coordinatesTitle}>Point de rencontre ⭐</Text>
            <Text style={styles.coordinatesText}>
              {meetingPoint.center.latitude.toFixed(6)}, {meetingPoint.center.longitude.toFixed(6)}
            </Text>
            <Text style={styles.coordinatesAddress}>{meetingPoint.address}</Text>
          </View>
        </View>
      </View>

      {/* Info Panel */}
      <View style={styles.infoPanel}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {/* Meeting Point Info Card */}
          <Card variant="elevated" style={styles.infoCard}>
            <Text style={styles.infoTitle}>Point de rencontre</Text>
            <Text style={styles.infoAddress} numberOfLines={2}>
              {meetingPoint.address || 'Adresse non disponible'}
            </Text>
            <View style={styles.statsRow}>
              <View style={styles.stat}>
                <Text style={styles.statLabel}>Temps moyen</Text>
                <Text style={styles.statValue}>
                  {formatDuration(meetingPoint.averageTravelTime)}
                </Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statLabel}>Temps max</Text>
                <Text style={styles.statValue}>
                  {formatDuration(meetingPoint.maxTravelTime)}
                </Text>
              </View>
            </View>
          </Card>

          {/* Travel Times Card */}
          <Card variant="elevated" style={styles.infoCard}>
            <Text style={styles.infoTitle}>Temps de trajet</Text>
            {meetingPoint.travelTimes.map((travelTime, index) => {
              const address = addresses.find(
                (a) => a.latitude === travelTime.origin.latitude &&
                       a.longitude === travelTime.origin.longitude
              );
              return (
                <View key={index} style={styles.travelTimeRow}>
                  <Text style={styles.travelTimeLabel} numberOfLines={1}>
                    {address?.label || `Adresse ${index + 1}`}
                  </Text>
                  <Text style={styles.travelTimeValue}>
                    {formatDuration(travelTime.durationSeconds)}
                  </Text>
                </View>
              );
            })}
          </Card>

          {/* Suggestions Cards */}
          {suggestions.map((suggestion) => (
            <Card
              key={suggestion.id}
              variant="elevated"
              style={[
                styles.infoCard,
                selectedSuggestion?.id === suggestion.id && styles.selectedCard,
              ]}
            >
              <TouchableOpacity onPress={() => handleSuggestionPress(suggestion)}>
                <Text style={styles.infoTitle}>{suggestion.name}</Text>
                <Text style={styles.suggestionType}>{suggestion.type}</Text>
                {suggestion.rating && (
                  <Text style={styles.rating}>⭐ {suggestion.rating.toFixed(1)}</Text>
                )}
                {suggestion.distance && (
                  <Text style={styles.distance}>
                    📍 {formatDistance(suggestion.distance)}
                  </Text>
                )}
                <TouchableOpacity
                  style={styles.navigateButton}
                  onPress={() => handleNavigateToSuggestion(suggestion)}
                >
                  <Text style={styles.navigateButtonText}>Itinéraire</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            </Card>
          ))}
        </ScrollView>
      </View>
    </View>
  );
};

