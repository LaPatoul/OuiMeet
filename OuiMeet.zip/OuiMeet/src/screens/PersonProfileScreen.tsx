import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/types';
import { theme } from '../constants/theme';
import { Button, Input, Card } from '../components/ui';
import { Person, Address, Preferences } from '../types';
import { updatePerson, deletePerson } from '../services/firestore';

type Props = NativeStackScreenProps<RootStackParamList, 'PersonProfile'>;

export const PersonProfileScreen: React.FC<Props> = ({ route, navigation }) => {
  const { personId } = route.params;
  const [person, setPerson] = useState<Person | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  useEffect(() => {
    // In a real app, fetch person from Firestore
    // For now, using mock data
    const mockPerson: Person = {
      id: personId,
      name: 'Marie Dupont',
      email: 'marie@example.com',
      preferences: {
        foodTypes: ['Italian', 'Japanese'],
        activityTypes: ['Cultural', 'Outdoor'],
        budget: 'medium',
      },
      savedAddresses: [
        {
          id: '1',
          label: 'Maison',
          fullAddress: '123 Rue de la Paix, Paris',
          latitude: 48.8566,
          longitude: 2.3522,
        },
      ],
    };

    setPerson(mockPerson);
    setName(mockPerson.name);
    setEmail(mockPerson.email || '');
    setLoading(false);
  }, [personId]);

  const handleSave = async () => {
    if (!person) return;

    setSaving(true);

    const updatedPerson: Partial<Person> = {
      name,
      email: email || undefined,
    };

    const { error } = await updatePerson(personId, updatedPerson);

    if (error) {
      Alert.alert('Erreur', error);
    } else {
      setPerson({ ...person, ...updatedPerson });
      setEditing(false);
      Alert.alert('Succès', 'Profil mis à jour avec succès');
    }

    setSaving(false);
  };

  const handleDelete = () => {
    Alert.alert(
      'Supprimer le contact',
      'Êtes-vous sûr de vouloir supprimer ce contact ?',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            const { error } = await deletePerson(personId);
            if (error) {
              Alert.alert('Erreur', error);
            } else {
              navigation.goBack();
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color={theme.colors.primary.main} />
      </View>
    );
  }

  if (!person) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Contact non trouvé</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profil du contact</Text>
        <TouchableOpacity
          onPress={() => setEditing(!editing)}
          style={styles.editButton}
        >
          <Text style={styles.editButtonText}>{editing ? 'Annuler' : 'Modifier'}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Avatar */}
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{person.name.charAt(0).toUpperCase()}</Text>
          </View>
        </View>

        {/* Basic Info */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Informations</Text>

          {editing ? (
            <>
              <Input
                label="Nom"
                value={name}
                onChangeText={setName}
                containerStyle={styles.input}
              />
              <Input
                label="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                containerStyle={styles.input}
              />
              <Button
                title={saving ? 'Enregistrement...' : 'Enregistrer'}
                onPress={handleSave}
                disabled={saving}
                style={styles.saveButton}
              />
            </>
          ) : (
            <>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Nom</Text>
                <Text style={styles.infoValue}>{person.name}</Text>
              </View>
              {person.email && (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Email</Text>
                  <Text style={styles.infoValue}>{person.email}</Text>
                </View>
              )}
            </>
          )}
        </Card>

        {/* Saved Addresses */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Adresses enregistrées</Text>
            <TouchableOpacity>
              <Text style={styles.addLink}>+ Ajouter</Text>
            </TouchableOpacity>
          </View>

          {person.savedAddresses.length === 0 ? (
            <Text style={styles.emptyText}>Aucune adresse enregistrée</Text>
          ) : (
            person.savedAddresses.map((address) => (
              <View key={address.id} style={styles.addressItem}>
                <View style={styles.addressIcon}>
                  <Text>📍</Text>
                </View>
                <View style={styles.addressInfo}>
                  <Text style={styles.addressLabel}>{address.label}</Text>
                  <Text style={styles.addressText}>{address.fullAddress}</Text>
                </View>
              </View>
            ))
          )}
        </Card>

        {/* Preferences */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Préférences</Text>
            <TouchableOpacity
              onPress={() =>
                navigation.navigate('EditPreferences', { personId: person.id })
              }
            >
              <Text style={styles.editLink}>Modifier</Text>
            </TouchableOpacity>
          </View>

          {person.preferences.foodTypes && person.preferences.foodTypes.length > 0 && (
            <View style={styles.preferenceGroup}>
              <Text style={styles.preferenceLabel}>Cuisine</Text>
              <View style={styles.tags}>
                {person.preferences.foodTypes.map((food, index) => (
                  <View key={index} style={styles.tag}>
                    <Text style={styles.tagText}>{food}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {person.preferences.activityTypes && person.preferences.activityTypes.length > 0 && (
            <View style={styles.preferenceGroup}>
              <Text style={styles.preferenceLabel}>Activités</Text>
              <View style={styles.tags}>
                {person.preferences.activityTypes.map((activity, index) => (
                  <View key={index} style={styles.tag}>
                    <Text style={styles.tagText}>{activity}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {person.preferences.budget && (
            <View style={styles.preferenceGroup}>
              <Text style={styles.preferenceLabel}>Budget</Text>
              <Text style={styles.preferenceValue}>
                {person.preferences.budget === 'low' && 'Économique (€)'}
                {person.preferences.budget === 'medium' && 'Moyen (€€)'}
                {person.preferences.budget === 'high' && 'Élevé (€€€)'}
              </Text>
            </View>
          )}
        </Card>

        {/* Delete Button */}
        <Button
          title="Supprimer le contact"
          onPress={handleDelete}
          variant="outline"
          style={styles.deleteButton}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background.primary,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: theme.spacing['3xl'],
    paddingHorizontal: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    backgroundColor: theme.colors.background.primary,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border.light,
  },

  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },

  backButtonText: {
    fontSize: theme.typography.fontSize['2xl'],
    color: theme.colors.text.primary,
  },

  headerTitle: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.text.primary,
  },

  editButton: {
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
  },

  editButtonText: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.primary.main,
    fontWeight: theme.typography.fontWeight.medium,
  },

  content: {
    flex: 1,
  },

  scrollContent: {
    padding: theme.spacing.lg,
    paddingBottom: theme.spacing['2xl'],
  },

  avatarContainer: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },

  avatar: {
    width: 100,
    height: 100,
    borderRadius: theme.borderRadius.full,
    backgroundColor: theme.colors.primary.main,
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarText: {
    fontSize: 40,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.text.inverse,
  },

  section: {
    marginBottom: theme.spacing.lg,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },

  sectionTitle: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.text.primary,
  },

  addLink: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.primary.main,
    fontWeight: theme.typography.fontWeight.medium,
  },

  editLink: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.primary.main,
    fontWeight: theme.typography.fontWeight.medium,
  },

  input: {
    marginBottom: theme.spacing.md,
  },

  saveButton: {
    marginTop: theme.spacing.sm,
  },

  infoRow: {
    marginBottom: theme.spacing.md,
  },

  infoLabel: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.secondary,
    marginBottom: theme.spacing.xs,
  },

  infoValue: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.text.primary,
    fontWeight: theme.typography.fontWeight.medium,
  },

  emptyText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.tertiary,
    textAlign: 'center',
    paddingVertical: theme.spacing.md,
  },

  addressItem: {
    flexDirection: 'row',
    paddingVertical: theme.spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border.light,
  },

  addressIcon: {
    marginRight: theme.spacing.sm,
  },

  addressInfo: {
    flex: 1,
  },

  addressLabel: {
    fontSize: theme.typography.fontSize.base,
    fontWeight: theme.typography.fontWeight.medium,
    color: theme.colors.text.primary,
    marginBottom: theme.spacing.xs,
  },

  addressText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.secondary,
  },

  preferenceGroup: {
    marginBottom: theme.spacing.md,
  },

  preferenceLabel: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.secondary,
    marginBottom: theme.spacing.xs,
  },

  preferenceValue: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.text.primary,
  },

  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing.xs,
  },

  tag: {
    backgroundColor: theme.colors.primary.light,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.md,
    marginRight: theme.spacing.xs,
    marginBottom: theme.spacing.xs,
  },

  tagText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.primary.dark,
    fontWeight: theme.typography.fontWeight.medium,
  },

  deleteButton: {
    marginTop: theme.spacing.lg,
    borderColor: theme.colors.error,
  },

  errorText: {
    fontSize: theme.typography.fontSize.base,
    color: theme.colors.text.secondary,
    textAlign: 'center',
  },
});
