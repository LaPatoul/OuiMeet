import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/types';
import { theme } from '../constants/theme';
import { Button, Card } from '../components/ui';
import { Preferences } from '../types';
import { updatePerson } from '../services/firestore';

type Props = NativeStackScreenProps<RootStackParamList, 'EditPreferences'>;

const FOOD_TYPES = [
  'Italian',
  'Japanese',
  'French',
  'Chinese',
  'Indian',
  'Mexican',
  'Thai',
  'Mediterranean',
  'Vegetarian',
  'Vegan',
];

const ACTIVITY_TYPES = [
  'Cultural',
  'Outdoor',
  'Sports',
  'Music',
  'Arts',
  'Shopping',
  'Relaxation',
  'Adventure',
  'Nightlife',
];

const BUDGET_OPTIONS = [
  { value: 'low', label: 'Économique', symbol: '€' },
  { value: 'medium', label: 'Moyen', symbol: '€€' },
  { value: 'high', label: 'Élevé', symbol: '€€€' },
];

export const EditPreferencesScreen: React.FC<Props> = ({ route, navigation }) => {
  const { personId } = route.params;
  const [foodTypes, setFoodTypes] = useState<string[]>([]);
  const [activityTypes, setActivityTypes] = useState<string[]>([]);
  const [budget, setBudget] = useState<'low' | 'medium' | 'high'>('medium');
  const [accessibility, setAccessibility] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // In a real app, fetch person's current preferences from Firestore
    // For now, using mock data
    setFoodTypes(['Italian', 'Japanese']);
    setActivityTypes(['Cultural', 'Outdoor']);
    setBudget('medium');
    setAccessibility(false);
  }, [personId]);

  const toggleFoodType = (food: string) => {
    setFoodTypes((prev) =>
      prev.includes(food) ? prev.filter((f) => f !== food) : [...prev, food]
    );
  };

  const toggleActivityType = (activity: string) => {
    setActivityTypes((prev) =>
      prev.includes(activity) ? prev.filter((a) => a !== activity) : [...prev, activity]
    );
  };

  const handleSave = async () => {
    setSaving(true);

    const preferences: Preferences = {
      foodTypes,
      activityTypes,
      budget,
      accessibility,
    };

    const { error } = await updatePerson(personId, { preferences });

    if (error) {
      Alert.alert('Erreur', error);
    } else {
      Alert.alert('Succès', 'Préférences enregistrées avec succès', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    }

    setSaving(false);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Modifier les préférences</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Food Types */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Types de cuisine</Text>
          <Text style={styles.sectionSubtitle}>
            Sélectionnez les types de cuisine préférés
          </Text>

          <View style={styles.optionsGrid}>
            {FOOD_TYPES.map((food) => (
              <TouchableOpacity
                key={food}
                onPress={() => toggleFoodType(food)}
                style={[
                  styles.optionChip,
                  foodTypes.includes(food) && styles.optionChipSelected,
                ]}
              >
                <Text
                  style={[
                    styles.optionChipText,
                    foodTypes.includes(food) && styles.optionChipTextSelected,
                  ]}
                >
                  {food}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        {/* Activity Types */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Types d'activités</Text>
          <Text style={styles.sectionSubtitle}>
            Sélectionnez les types d'activités préférées
          </Text>

          <View style={styles.optionsGrid}>
            {ACTIVITY_TYPES.map((activity) => (
              <TouchableOpacity
                key={activity}
                onPress={() => toggleActivityType(activity)}
                style={[
                  styles.optionChip,
                  activityTypes.includes(activity) && styles.optionChipSelected,
                ]}
              >
                <Text
                  style={[
                    styles.optionChipText,
                    activityTypes.includes(activity) && styles.optionChipTextSelected,
                  ]}
                >
                  {activity}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        {/* Budget */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Budget</Text>
          <Text style={styles.sectionSubtitle}>
            Sélectionnez le niveau de budget préféré
          </Text>

          <View style={styles.budgetOptions}>
            {BUDGET_OPTIONS.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => setBudget(option.value as 'low' | 'medium' | 'high')}
                style={[
                  styles.budgetOption,
                  budget === option.value && styles.budgetOptionSelected,
                ]}
              >
                <Text style={styles.budgetSymbol}>{option.symbol}</Text>
                <Text
                  style={[
                    styles.budgetLabel,
                    budget === option.value && styles.budgetLabelSelected,
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        {/* Accessibility */}
        <Card variant="elevated" padding="lg" style={styles.section}>
          <TouchableOpacity
            onPress={() => setAccessibility(!accessibility)}
            style={styles.accessibilityOption}
          >
            <View style={styles.accessibilityInfo}>
              <Text style={styles.sectionTitle}>Accessibilité</Text>
              <Text style={styles.sectionSubtitle}>
                Prioriser les lieux accessibles aux personnes à mobilité réduite
              </Text>
            </View>
            <View
              style={[
                styles.checkbox,
                accessibility && styles.checkboxChecked,
              ]}
            >
              {accessibility && <Text style={styles.checkmark}>✓</Text>}
            </View>
          </TouchableOpacity>
        </Card>

        {/* Save Button */}
        <Button
          title={saving ? 'Enregistrement...' : 'Enregistrer les préférences'}
          onPress={handleSave}
          size="lg"
          fullWidth
          disabled={saving}
          style={styles.saveButton}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background.primary,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: theme.spacing['3xl'],
    paddingHorizontal: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    backgroundColor: theme.colors.background.primary,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border.light,
  },

  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },

  backButtonText: {
    fontSize: theme.typography.fontSize['2xl'],
    color: theme.colors.text.primary,
  },

  headerTitle: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.text.primary,
  },

  headerSpacer: {
    width: 40,
  },

  content: {
    flex: 1,
  },

  scrollContent: {
    padding: theme.spacing.lg,
    paddingBottom: theme.spacing['2xl'],
  },

  section: {
    marginBottom: theme.spacing.lg,
  },

  sectionTitle: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.semibold,
    color: theme.colors.text.primary,
    marginBottom: theme.spacing.xs,
  },

  sectionSubtitle: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.secondary,
    marginBottom: theme.spacing.md,
  },

  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing.sm,
  },

  optionChip: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.full,
    borderWidth: 1,
    borderColor: theme.colors.border.main,
    backgroundColor: theme.colors.background.card,
  },

  optionChipSelected: {
    backgroundColor: theme.colors.primary.main,
    borderColor: theme.colors.primary.main,
  },

  optionChipText: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.primary,
    fontWeight: theme.typography.fontWeight.medium,
  },

  optionChipTextSelected: {
    color: theme.colors.text.inverse,
  },

  budgetOptions: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },

  budgetOption: {
    flex: 1,
    padding: theme.spacing.lg,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 2,
    borderColor: theme.colors.border.main,
    backgroundColor: theme.colors.background.card,
    alignItems: 'center',
  },

  budgetOptionSelected: {
    borderColor: theme.colors.primary.main,
    backgroundColor: theme.colors.primary.light,
  },

  budgetSymbol: {
    fontSize: theme.typography.fontSize['2xl'],
    color: theme.colors.primary.main,
    marginBottom: theme.spacing.xs,
    fontWeight: theme.typography.fontWeight.bold,
  },

  budgetLabel: {
    fontSize: theme.typography.fontSize.sm,
    color: theme.colors.text.primary,
    fontWeight: theme.typography.fontWeight.medium,
  },

  budgetLabelSelected: {
    color: theme.colors.primary.dark,
    fontWeight: theme.typography.fontWeight.semibold,
  },

  accessibilityOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  accessibilityInfo: {
    flex: 1,
    marginRight: theme.spacing.md,
  },

  checkbox: {
    width: 32,
    height: 32,
    borderRadius: theme.borderRadius.sm,
    borderWidth: 2,
    borderColor: theme.colors.border.main,
    alignItems: 'center',
    justifyContent: 'center',
  },

  checkboxChecked: {
    backgroundColor: theme.colors.primary.main,
    borderColor: theme.colors.primary.main,
  },

  checkmark: {
    color: theme.colors.text.inverse,
    fontSize: theme.typography.fontSize.lg,
    fontWeight: theme.typography.fontWeight.bold,
  },

  saveButton: {
    marginTop: theme.spacing.lg,
  },
});
